<div class="content-wrapper">
  <h1>Halaman Home</h1>  
</div>